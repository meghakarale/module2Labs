# Sales Dashboard: Hosting Bundle

This bundle contains everything needed to host the Sales Dashboard on an Oracle Cloud (OCI) instance running Oracle Linux 9 and share it with a client by link.

| File | What it is |
|---|---|
| `sales-dashboard/index.html` | The dashboard: a single, self-contained web page. No internet connection or other files needed. |
| `deploy/setup-oci.sh` | Server setup script: installs the nginx web server, publishes the dashboard and opens the firewall. Safe to run again. |
| `sample-data/csv-template.csv` | The CSV layout the dashboard expects. Contains only the header and two example rows. |
| `README.md` | This guide. |

---

## 1. What the dashboard does

- **Load CSV file** button (or drag and drop) to open a sales CSV.
- Headline cards: **Total Revenue, Total Units Sold, Best Region, Best Product**.
- **Region** and **Product** filters: everything updates instantly.
- **Insights** box: best month, fastest-growing region (first vs last quarter), highest average price per unit.
- Charts: revenue by region (bar) and revenue by month (line).
- Product × region table with totals; click any column heading to sort.
- **Print / Save as PDF**: A4 landscape, page 1 = cards, insights and charts; page 2 = table.
- Amounts in Indian rupees, shown in lakhs (L) and crores (Cr).

**Privacy:** the CSV is read inside the viewer's own browser. It is never uploaded to the server.

### CSV format

The first row must contain these column names (in any order, upper or lower case):

```
Month,Region,Product,Units,Revenue
2025-01,North,Laptop,43,2681935
2025-01,South,Monitor,43,593260
```

- **Month**: `YYYY-MM` (e.g. `2025-01`). Most ordinary date formats also work.
- **Units** and **Revenue**: plain numbers. Commas and the ₹ sign are ignored, so `₹26,81,935` is fine.

---

## 2. One-time OCI setup

### 2.1 Create the instance (skip if it already exists)

In the OCI console: **Compute → Instances → Create instance**

1. **Region:** Germany Central (Frankfurt), `eu-frankfurt-1`.
2. **Image:** Oracle Linux 9. **Shape:** your provisioned shape (e.g. 12 GB RAM, 100 GB boot volume).
3. **Networking:** choose a **public subnet** and keep **Assign a public IPv4 address** ticked.
4. **Add SSH keys:** choose **Generate a key pair** and **download the private key** (e.g. `ssh-key-2026-10-30.key`). Keep it safe; it is the only way in.
5. Create, wait until the state is **Running**, and note the **Public IP address**.

### 2.2 Allow web traffic (port 80)

OCI has its own firewall in addition to the server's. Without this rule the link will not open from outside.

**Instance details → Subnet → Security Lists → Default Security List → Add Ingress Rules**

| Field | Value |
|---|---|
| Source Type | CIDR |
| Source CIDR | `0.0.0.0/0` |
| IP Protocol | TCP |
| Destination Port Range | `80` |

SSH (port 22) is normally allowed by the default rules already.

---

## 3. Deploy using OCI Cloud Shell (recommended)

Cloud Shell is a Linux terminal inside the OCI console, so nothing needs installing on your PC.

Replace `<IP>` below with your instance's public IP, and the key file name with yours if it differs.

**Step 1: Open Cloud Shell and upload files.**
Click the **>_** icon at the top right of the OCI console. In the Cloud Shell window menu (gear or ☰ icon) choose **Upload** and upload these three files:

- `sales-dashboard/index.html`
- `deploy/setup-oci.sh`
- your private key, e.g. `ssh-key-2026-10-30.key`

**Step 2: Store the key safely** (only needed once)

```bash
mkdir -p ~/.ssh
mv ~/ssh-key-2026-10-30.key ~/.ssh/
chmod 600 ~/.ssh/ssh-key-2026-10-30.key
```

**Step 3: Copy the files to the instance**

```bash
scp -i ~/.ssh/ssh-key-2026-10-30.key ~/index.html ~/setup-oci.sh opc@<IP>:/home/opc/
```

The first time, type `yes` when asked "Are you sure you want to continue connecting?".

**Step 4: Log in and run the setup**

```bash
ssh -i ~/.ssh/ssh-key-2026-10-30.key opc@<IP>
sed -i 's/\r$//' setup-oci.sh
sudo bash setup-oci.sh
exit
```

The `sed` line removes Windows line endings if they crept in during upload; it is harmless otherwise.
The script finishes with **Done** and the link to share: `http://<IP>/`.

### Alternative: deploy from a Windows PC (PowerShell)

```powershell
# Only if Windows says the key permissions are "too open":
icacls "C:\path\to\ssh-key-2026-10-30.key" /inheritance:r /grant:r "$($env:USERNAME):R"

scp -i "C:\path\to\ssh-key-2026-10-30.key" "sales-dashboard\index.html" "deploy\setup-oci.sh" opc@<IP>:/home/opc/
ssh -i "C:\path\to\ssh-key-2026-10-30.key" opc@<IP>
```

Then, on the server: `sed -i 's/\r$//' setup-oci.sh` and `sudo bash setup-oci.sh`.

---

## 4. What the setup script does

1. Installs **nginx** (the web server) with `dnf`.
2. Copies `index.html` into `/usr/share/nginx/html/` and applies the correct **SELinux** label (prevents "403 Forbidden").
3. Adds small security and compression settings in `/etc/nginx/conf.d/sales-dashboard.conf`.
4. Starts nginx and sets it to start automatically after a reboot.
5. Opens port 80 in the server firewall (`firewalld`).
6. Checks the page is being served and prints the link.

---

## 5. Check it works

1. Open `http://<IP>/` on your PC. The dashboard should appear with the **Load CSV file** button.
2. Load a CSV and check the cards, charts and table.
3. Ideally, also try on a phone using mobile data, to confirm it opens from outside your network.

---

## 6. Publishing an updated dashboard

1. Upload the new `index.html` to Cloud Shell (it replaces the old one).
2. Run Step 3 (`scp …`) and then on the server `sudo bash setup-oci.sh`.

The old page is replaced; the link stays the same.

---

## 7. Sharing with the client

Send them:

- The link: `http://<IP>/`
- The CSV format from section 1 (or the `csv-template.csv` file).

Points worth mentioning:

- The browser will show **"Not secure"** next to the address because the site uses plain `http://` without a domain name. The dashboard still works, and their CSV never leaves their computer.
- Anyone with the link can open the page (it holds no data until a CSV is loaded).
- **Print / Save as PDF** produces an A4 landscape report. If colours look faded, turn on **Background graphics** in the print dialog's *More settings*.

---

## 8. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| Link keeps loading, then times out | Port 80 ingress rule missing in the OCI Security List (section 2.2). |
| `scp` / `ssh` hangs, then times out | Port 22 blocked, or the instance has no public IP / is not in a public subnet. |
| `Permission denied (publickey)` | Use user `opc` and the private key downloaded when *this* instance was created; check `chmod 600` on the key. |
| `UNPROTECTED PRIVATE KEY FILE` | Run `chmod 600` on the key (Cloud Shell) or the `icacls` command (Windows). |
| `403 Forbidden` in the browser | File label issue: on the server run `sudo restorecon -Rv /usr/share/nginx/html`. |
| Script fails with `$'\r': command not found` | Windows line endings: run `sed -i 's/\r$//' setup-oci.sh` first. |
| Page works but shows nothing | Expected: click **Load CSV file** and choose a CSV. |
| Error "missing these columns" after loading | The CSV header must include Month, Region, Product, Units, Revenue. |

Useful server commands:

```bash
sudo systemctl status nginx           # is the web server running?
sudo journalctl -u nginx --since today
sudo tail -n 50 /var/log/nginx/error.log
```

---

## 9. Optional upgrades later

- **HTTPS with a padlock:** needs a domain name (e.g. `dashboard.yourcompany.com`) pointed at the instance IP; then a free Let's Encrypt certificate can be added with `certbot`, plus an ingress rule for port 443.
- **Password protection:** nginx basic authentication (username and password prompt), ideally combined with HTTPS.
